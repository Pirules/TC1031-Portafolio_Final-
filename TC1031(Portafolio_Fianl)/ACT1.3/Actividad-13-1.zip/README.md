# Actividad-1.3

Para la clase de Estructura de datos y algoritmos fundamentales TC1031
Actividad de implementacion de algoritmos de busqueda y de ordenamiento, en este caso utilizando una implementacion de merge sort.
